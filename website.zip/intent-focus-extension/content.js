console.log("IntentFocus: Tracker Active.");

// GLOBALS
let sessionStartTime = Date.now();
let currentSessionID = null;

// 1. HEARTBEAT & OVERLAY CHECKER
setInterval(() => {
    // Kill switch for dev mode reloading
    if (!chrome.runtime?.id) return;

    const isSocial = isSocialSite();
    const hasOverlay = document.getElementById("intent-overlay");
    const isUnlocked = sessionStorage.getItem("intentUnlocked"); 

    // IF social site AND no overlay AND not unlocked -> BLOCK
    if (isSocial && !hasOverlay && !isUnlocked) {
        createOverlay();
    }
}, 1000);

// 2. TIME TRACKER (Updates every 60 seconds)
setInterval(() => {
    if (currentSessionID && chrome.runtime?.id) {
        updateDuration(currentSessionID);
    }
}, 60000); // 1 minute

function isSocialSite() {
    const url = window.location.hostname;
    // Add any site you want to track here
    const targets = ["youtube.com", "instagram.com", "twitter.com", "x.com", "facebook.com", "tiktok.com", "reddit.com", "linkedin.com", "pinterest.com", "twitch.tv"];
    return targets.some(t => url.includes(t));
}

function createOverlay() {
    if (document.getElementById("intent-overlay")) return;

    const overlay = document.createElement("div");
    overlay.id = "intent-overlay";
    
    // Using the same HTML structure as before
    overlay.innerHTML = `
        <div id="intent-card">
            <div class="intent-header">
                <span style="font-size: 40px; display: block; margin-bottom: 10px;">🛑</span>
                <h1>Hold on.</h1>
                <p>What is your intention?</p>
            </div>
            <div class="intent-grid">
                <button class="intent-btn good" data-reason="🎯 Intentional"><span>🎯</span> Intentional</button>
                <button class="intent-btn warn" data-reason="😵 Boredom"><span>😵</span> Boredom</button>
                <button class="intent-btn warn" data-reason="🔁 Habit"><span>🔁</span> Habit</button>
                <button class="intent-btn urgent" data-reason="🚨 Urgent"><span>🔥</span> Urgent</button>
            </div>
        </div>
    `;

    document.body.appendChild(overlay);
    document.body.style.overflow = "hidden";
    
    overlay.querySelectorAll('.intent-btn').forEach(btn => {
        btn.onclick = () => handleChoice(btn.dataset.reason);
    });
}

function handleChoice(reason) {
    const overlay = document.getElementById("intent-overlay");
    
    // Generate a unique ID for this specific visit
    currentSessionID = Date.now();

    if (chrome.runtime?.id) {
        saveStats(reason, currentSessionID);
    }

    sessionStorage.setItem("intentUnlocked", "true");

    overlay.style.opacity = "0";
    setTimeout(() => {
        overlay.remove();
        document.body.style.overflow = "auto"; 
    }, 400);
}

function saveStats(reason, id) {
    const today = new Date().toLocaleDateString();
    
    chrome.storage.local.get([today], function(result) {
        if (chrome.runtime.lastError) return;
        
        let currentData = result[today] || [];
        
        currentData.push({
            id: id,
            reason: reason,
            time: new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}),
            site: window.location.hostname.replace('www.', ''),
            durationMinutes: 0 // Start at 0
        });
        
        chrome.storage.local.set({ [today]: currentData });
    });
}

function updateDuration(id) {
    const today = new Date().toLocaleDateString();
    
    chrome.storage.local.get([today], function(result) {
        let currentData = result[today] || [];
        
        // Find our session and add 1 minute
        const sessionIndex = currentData.findIndex(x => x.id === id);
        if (sessionIndex !== -1) {
            currentData[sessionIndex].durationMinutes += 1;
            chrome.storage.local.set({ [today]: currentData });
            console.log("IntentFocus: Added 1 min to log.");
        }
    });
}