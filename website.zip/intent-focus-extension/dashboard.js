document.addEventListener("DOMContentLoaded", () => {
    loadData();
    setupNavigation();
});

function setupNavigation() {
    const navs = {'btn-dash': 'view-dash', 'btn-analytics': 'view-analytics', 'btn-settings': 'view-settings'};
    
    for (const [btnId, viewId] of Object.entries(navs)) {
        const btn = document.getElementById(btnId);
        if (btn) {
            btn.addEventListener('click', () => {
                document.querySelectorAll('.nav-item').forEach(el => el.classList.remove('active'));
                document.querySelectorAll('.view-section').forEach(el => el.classList.remove('active'));
                
                btn.classList.add('active');
                document.getElementById(viewId).classList.add('active');
            });
        }
    }
}

function loadData() {
    const today = new Date().toLocaleDateString();
    
    // Greeting Logic
    const hour = new Date().getHours();
    const titleEl = document.getElementById('page-title');
    if(titleEl) {
        if(hour < 12) titleEl.innerText = "Good Morning.";
        else if(hour < 18) titleEl.innerText = "Good Afternoon.";
        else titleEl.innerText = "Good Evening.";
    }

    chrome.storage.local.get([today], (result) => {
        let data = result[today] || [];
        
        // HACK: If data is empty for demo, show nothing or dummy data?
        // Let's stick to real data to avoid confusion.
        
        renderOverview(data);
        renderAnalytics(data);
    });
}

// 1. RENDER OVERVIEW TAB
function renderOverview(data) {
    let good = 0;
    let bad = 0;

    data.forEach(item => {
        if(item.reason.includes("Intentional") || item.reason.includes("Work")) good++; else bad++;
    });

    document.getElementById('val-total').innerText = data.length;
    document.getElementById('val-good').innerText = good;
    document.getElementById('val-bad').innerText = bad;

    const tbody = document.getElementById('table-body');
    tbody.innerHTML = "";

    if(data.length === 0) {
        tbody.innerHTML = "<tr><td colspan='4' style='text-align:center; padding:30px; color:#999;'>No sessions tracked yet.</td></tr>";
        return;
    }

    data.slice().reverse().forEach(row => {
        let pillClass = "pill-warn";
        let icon = "🍂";
        
        if(row.reason.includes("Intentional") || row.reason.includes("Work")) {
            pillClass = "pill-good"; icon = "✨";
        } else if (row.reason.includes("Urgent")) {
            pillClass = "pill-urgent"; icon = "🔥";
        }

        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td style="font-weight: 500;">${row.site}</td>
            <td style="color: #666;">${row.time}</td>
            <td>${row.reason}</td>
            <td><span class="pill ${pillClass}">${icon} ${row.reason.split(" ")[0]}</span></td>
        `;
        tbody.appendChild(tr);
    });
}

// 2. RENDER ANALYTICS TAB
function renderAnalytics(data) {
    if (data.length === 0) return;

    // A. SITE FREQUENCY
    const siteCounts = {};
    data.forEach(item => {
        siteCounts[item.site] = (siteCounts[item.site] || 0) + 1;
    });

    const sortedSites = Object.entries(siteCounts).sort((a,b) => b[1] - a[1]).slice(0, 5);
    const maxCount = sortedSites[0][1];
    
    const siteContainer = document.getElementById('top-sites-container');
    siteContainer.innerHTML = "";

    sortedSites.forEach(([site, count]) => {
        const pct = (count / maxCount) * 100;
        siteContainer.innerHTML += `
            <div class="chart-row">
                <div class="chart-label"><span>${site}</span><span>${count} visits</span></div>
                <div class="progress-bg"><div class="progress-fill" style="width:${pct}%; background: #FDE68A;"></div></div>
            </div>
        `;
    });

    // B. INTENT PIE CHART
    let mindful = 0;
    data.forEach(item => {
        if(item.reason.includes("Intentional") || item.reason.includes("Work")) mindful++;
    });
    
    const total = data.length;
    const mindfulPct = Math.round((mindful / total) * 100);
    const habitPct = 100 - mindfulPct;

    document.getElementById('pie-pct').innerText = mindfulPct + "%";
    
    // CSS Conic Gradient Trick
    const pieVisual = document.getElementById('pie-visual');
    pieVisual.style.background = `conic-gradient(#D1FAE5 0% ${mindfulPct}%, #FDE68A ${mindfulPct}% 100%)`;


    // C. TIME TRACKING (Summing up durationMinutes)
    const timeCounts = {};
    data.forEach(item => {
        const mins = item.durationMinutes || 0;
        timeCounts[item.site] = (timeCounts[item.site] || 0) + mins;
    });

    const timeContainer = document.getElementById('time-container');
    timeContainer.innerHTML = "";
    
    // Sort by time spent
    const sortedTime = Object.entries(timeCounts).sort((a,b) => b[1] - a[1]).slice(0, 5);
    
    if (sortedTime.length === 0 || sortedTime[0][1] === 0) {
        timeContainer.innerHTML = "<p style='color:#999'>Spend more time to see data.</p>";
    } else {
        const maxTime = sortedTime[0][1];
        sortedTime.forEach(([site, mins]) => {
            const pct = (mins / maxTime) * 100;
            timeContainer.innerHTML += `
                <div class="chart-row">
                    <div class="chart-label"><span>${site}</span><span>${mins} mins</span></div>
                    <div class="progress-bg"><div class="progress-fill" style="width:${pct}%; background: #E0E7FF;"></div></div>
                </div>
            `;
        });
    }
}