chrome.storage.local.get(["interval"], res => {
  document.getElementById("interval").value = res.interval || 60;
});

document.getElementById("save").onclick = () => {
  const v = Number(document.getElementById("interval").value);
  chrome.storage.local.set({ interval: v });
  alert("Saved!");
};
