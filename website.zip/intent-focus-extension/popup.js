document.getElementById("open-dash").addEventListener("click", () => {
    chrome.tabs.create({ url: "dashboard.html" });
});