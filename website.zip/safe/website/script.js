document.addEventListener('DOMContentLoaded', () => {
    
    // 1. Select all elements we want to animate
    const scrollElements = document.querySelectorAll('[data-scroll]');

    // 2. Add the hidden class initially
    scrollElements.forEach((el) => {
        el.classList.add('scroll-hidden');
    });

    // 3. Create the observer
    const observer = new IntersectionObserver((entries) => {
        entries.forEach((entry) => {
            if (entry.isIntersecting) {
                entry.target.classList.add('scroll-visible');
            }
        });
    }, {
        threshold: 0.1 // Trigger when 10% of element is visible
    });

    // 4. Observe elements
    scrollElements.forEach((el) => observer.observe(el));

    // 5. Hero Parallax Effect (Optional Polish)
    window.addEventListener('scroll', () => {
        const scrolled = window.scrollY;
        const heroImg = document.querySelector('.browser-mockup');
        if(heroImg) {
            heroImg.style.transform = `translateY(${scrolled * 0.1}px)`;
        }
    });
});